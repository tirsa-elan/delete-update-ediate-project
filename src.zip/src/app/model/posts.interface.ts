
export interface IPosts {
    id: number
    title: string
    views: number
}