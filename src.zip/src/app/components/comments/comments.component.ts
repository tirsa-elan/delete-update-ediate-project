import { Component } from "@angular/core";

@Component({
    selector : "app-comment",
    templateUrl : "./comments.component.html"
})
export class CommentsComponent{

}