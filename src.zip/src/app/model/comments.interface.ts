
export interface IComments {
    id: string
    title: string
    views: number
}