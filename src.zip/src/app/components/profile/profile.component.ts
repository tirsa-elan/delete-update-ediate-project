import { Component } from "@angular/core";

@Component({
    selector : "app-comment",
    templateUrl : "./profile.component.html"
})
export class ProfileComponent{

}