
export interface IProfile {
    id: string
    title: string
    views: number
}